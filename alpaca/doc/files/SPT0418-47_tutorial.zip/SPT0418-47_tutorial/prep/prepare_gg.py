"""
Prepare the ALPACA inputs of a galaxy-galaxy lens from a public JWST/NIRCam mosaic on MAST.

    python prepare_gg.py --name SPT0418-47 --ra 64.66533 --dec -47.86465 --filter F444W \
                         --theta-e 1.3 --keep-r 2.6 --aperture 3.2 --out data

What it does (each step is explained in the ALPACA galaxy-galaxy tutorial):
  1. finds the public level-3 mosaic (i2d) in that filter that contains the lens, and the level-2 exposures it was
     made from (only their headers are downloaded), and downloads the mosaic into raw/;
  2. finds the lens centre (a light-weighted centroid) and cuts a square frame centred on it;
  3. converts the image and its ERR extension (the 1-sigma noise) from MJy/sr to DN/s, marks bad pixels;
  4. finds every source with a segmentation map, keeps the lens + arcs, masks the rest, measures and subtracts the
     sky, and writes the two masks (likelihood mask on the model cutout, lens-only mask on the full frame);
  5. builds a model PSF with STPSF (used for the star cuts and as a comparison PSF);
  6. cuts PSF-star stamps around Gaia stars in the same mosaic and keeps the clean ones (filter_stars.py).
Then run reconstruct_psf_starred.py on the stars to get the empirical PSF that ALPACA uses.

Requirements: numpy, astropy, photutils, scipy, astroquery (MAST + Gaia), stpsf (+ its data files, STPSF_PATH).
This is a cleaned copy of the script that made the tutorial's inputs (same algorithm, command-line options instead of
a hard-coded target table).
"""
import argparse
import json
import os
import subprocess
import warnings
from concurrent.futures import ThreadPoolExecutor

import astropy.units as u
import numpy as np
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.nddata import Cutout2D
from astropy.stats import sigma_clipped_stats
from astropy.wcs import WCS
from photutils.centroids import centroid_2dg
from photutils.segmentation import deblend_sources, detect_sources
from scipy import ndimage

from filter_stars import min_concentration, min_peak_frac, star_ok

warnings.filterwarnings("ignore")

MAST = "https://mast.stsci.edu/api/v0.1/Download/file?uri=mast:JWST/product/"
OVERSAMPLE = 3
# pixel sizes per NIRCam channel (SW 0.031"/px, LW 0.063"/px): the same angular frame (15.6"), model cutout (6.8")
# and PSF stamp (4.6") in both
SIZES = {"SW": dict(frame=499, cutout=219, psf_native=149, star=81),
         "LW": dict(frame=249, cutout=109, psf_native=75, star=63)}


def log(*a):
    print(*a, flush=True)


def covering_exposures(coord, filt, workdir):
    """Level-2 cal exposures in `filt` whose detector contains `coord` (header-only range downloads)."""
    from astroquery.mast import Observations
    obs = Observations.query_criteria(coordinates=coord, radius=3 * u.arcsec, obs_collection="JWST",
                                      instrument_name="NIRCAM/IMAGE", filters=filt, calib_level=3,
                                      dataRights="PUBLIC")
    if len(obs) == 0:
        raise SystemExit(f"no public NIRCam {filt} level-3 data at {coord}")
    prods = Observations.get_product_list(obs)
    cal = sorted({str(s) for s in prods["productFilename"] if str(s).endswith("_cal.fits")})
    i2d = sorted({str(s) for s in prods["productFilename"]
                  if str(s).endswith("_i2d.fits") and "nircam_clear" in str(s)})
    os.makedirs(os.path.join(workdir, "hdrs"), exist_ok=True)

    def get(n):
        out = os.path.join(workdir, "hdrs", n)
        if not os.path.exists(out):
            subprocess.run(["curl", "-sSL", "--retry", "3", "-r", "0-86399", "-o", out, MAST + n], check=True)
        return out

    with ThreadPoolExecutor(16) as ex:
        paths = list(ex.map(get, cal))
    rows = []
    for n, p in zip(cal, paths):
        h = fits.open(p, ignore_missing_end=True)
        x, y = (float(v) for v in WCS(h[1].header).world_to_pixel(coord))
        if 4 < x < 2043 and 4 < y < 2043:
            rows.append(dict(file=n, detector=h[0].header["DETECTOR"],
                             date=f"{h[0].header['DATE-OBS']}T{h[0].header['TIME-OBS']}", x=x, y=y,
                             obs=n[2:7] + "-o" + n[7:10]))
    return rows, i2d


def stpsf_mosaic_frame(rows, coord, filt, mosaic_wcs, pixscale, workdir, psf_native):
    """Mean STPSF over the covering exposures, each rotated from its detector frame to the mosaic frame."""
    import stpsf
    nrc = stpsf.NIRCam()
    nrc.filter = filt
    psfs, opds = [], set()
    for r in rows:
        nrc.detector = r["detector"]
        nrc.detector_position = (r["x"], r["y"])
        try:
            nrc.load_wss_opd_by_date(r["date"], plot=False, verbose=False)
            opds.add(os.path.basename(str(nrc.pupilopd[0] if isinstance(nrc.pupilopd, tuple) else nrc.pupilopd)))
        except Exception as e:  # noqa: BLE001 - fall back to the default (predicted) OPD
            log("  OPD by date failed:", e)
        p = nrc.calc_psf(oversample=OVERSAMPLE, fov_pixels=psf_native)["OVERDIST"].data.astype("f8")
        cal_w = WCS(fits.open(os.path.join(workdir, "hdrs", r["file"]), ignore_missing_end=True)[1].header)
        rot = pa_of_yaxis(cal_w, coord) - pa_of_yaxis(mosaic_wcs, coord)
        p = ndimage.rotate(p, rot, reshape=False, order=3, mode="constant")
        zoom = nrc.pixelscale / pixscale
        if abs(zoom - 1) > 1e-3:
            p = ndimage.zoom(p, zoom, order=3)
        psfs.append(center_crop_odd(p, OVERSAMPLE * psf_native))
        log(f"  PSF {r['file']} {r['detector']} ({r['x']:.0f},{r['y']:.0f}) rot {rot:+.3f} deg zoom {zoom:.4f}")
    psf = np.clip(np.mean(psfs, axis=0), 0, None)
    return psf / psf.sum(), sorted(opds)


def pa_of_yaxis(w, coord):
    """Position angle (deg E of N) of the +y pixel axis at coord (mosaic and cal frames share parity)."""
    x, y = w.world_to_pixel(coord)
    return coord.position_angle(w.pixel_to_world(x, y + 10)).deg


def center_crop_odd(p, n):
    n = min(n, p.shape[0] - (1 - p.shape[0] % 2))
    n -= (n + 1) % 2
    cy, cx = np.unravel_index(np.argmax(ndimage.gaussian_filter(p, 2)), p.shape)
    h = n // 2
    return p[cy - h:cy + h + 1, cx - h:cx + h + 1]


def main(a):
    filt = a.filter.upper()
    sz = SIZES["LW" if int(filt[1:4]) >= 250 else "SW"]
    FRAME, CUTOUT, STAR_SIZE = sz["frame"], sz["cutout"], sz["star"]
    coord = SkyCoord(a.ra, a.dec, unit="deg")
    work, out = os.path.abspath(a.work), os.path.abspath(a.out)
    os.makedirs(out, exist_ok=True)

    # ------------------------------------------------------------------ 1. data discovery + download
    rows, i2d = covering_exposures(coord, filt, work)
    obs_ids = sorted({r["obs"] for r in rows})
    log(f"{a.name}: {len(rows)} covering {filt} exposures in {obs_ids}")
    best = max(obs_ids, key=lambda o: sum(r["obs"] == o for r in rows))   # the observation with most exposures
    rows = [r for r in rows if r["obs"] == best]
    mosaic_name = [n for n in i2d if n.startswith(f"jw{best}_") and filt.lower() in n][0]
    mosaic = os.path.join(work, "raw", mosaic_name)
    if not os.path.exists(mosaic):
        os.makedirs(os.path.dirname(mosaic), exist_ok=True)
        log(f"downloading {mosaic_name} ...")
        subprocess.run(["curl", "-sSL", "--retry", "3", "-o", mosaic + ".part", MAST + mosaic_name], check=True)
        os.replace(mosaic + ".part", mosaic)
    json.dump(rows, open(os.path.join(out, "lens_exposures.json"), "w"), indent=1)

    hdul = fits.open(mosaic, memmap=True)
    sci_h = hdul["SCI"].header
    wcs = WCS(sci_h)
    photmjsr = sci_h["PHOTMJSR"]                     # MJy/sr per DN/s
    pixscale = np.sqrt(abs(np.linalg.det(wcs.pixel_scale_matrix))) * 3600.0
    sci, err = hdul["SCI"].data, hdul["ERR"].data

    # ------------------------------------------------------------------ 2. lens centre + frame
    x0, y0 = (float(v) for v in wcs.world_to_pixel(coord))
    ix, iy = int(round(x0)), int(round(y0))
    box = sci[iy - 7:iy + 8, ix - 7:ix + 8]
    cx, cy = centroid_2dg(box - np.nanmedian(box))
    xc, yc = ix - 7 + cx, iy - 7 + cy
    log(f"pixel scale {pixscale:.5f}\"  catalog ({x0:.2f},{y0:.2f}) -> centroid ({xc:.2f},{yc:.2f}), "
        f"offset {coord.separation(wcs.pixel_to_world(xc, yc)).arcsec:.3f}\"")
    pos = (int(round(xc)), int(round(yc)))
    cut_sci = Cutout2D(sci, pos, FRAME, wcs=wcs, mode="partial", fill_value=np.nan)
    cut_err = Cutout2D(err, pos, FRAME, wcs=wcs, mode="partial", fill_value=np.nan)

    # ------------------------------------------------------------------ 3. units, noise, bad pixels
    img = (cut_sci.data / photmjsr).astype("f4")
    noise = (cut_err.data / photmjsr).astype("f4")
    bad = ~np.isfinite(img) | ~np.isfinite(noise) | (noise <= 0)
    img[bad] = 0.0
    noise[bad] = 1e6 * np.nanmax(noise[~bad])
    off_x, off_y = xc - pos[0], yc - pos[1]
    log(f"bad pixels in frame: {bad.sum()}, lens offset from frame centre ({off_x:.3f}, {off_y:.3f}) px")

    # ------------------------------------------------------------------ 4. masks + sky
    _, med, _ = sigma_clipped_stats(img[~bad], sigma=3)
    smooth = ndimage.gaussian_filter(img - med, 1.0)
    seg = detect_sources(smooth, 1.5 * noise, n_pixels=15)
    seg = deblend_sources(smooth, seg, n_pixels=15, n_levels=32, contrast=0.005, progress_bar=False)
    yy, xx = np.indices(img.shape)
    r = np.hypot(xx - FRAME // 2, yy - FRAME // 2)
    keep = set(np.unique(seg.data[(r < a.keep_r / pixscale) & (seg.data > 0)])) - {0}     # lens + arcs
    others = ndimage.binary_dilation(np.isin(seg.data, [lab for lab in seg.labels if lab not in keep]), iterations=6)
    sky_pix = (seg.data == 0) & ~bad & (r > (a.keep_r + 1.0) / pixscale)
    _, sky, sky_std = sigma_clipped_stats(img[sky_pix], sigma=3)
    img[~bad] -= sky
    log(f"segments {seg.nlabels}, kept {sorted(int(k) for k in keep)}; sky {sky:.5f} DN/s "
        f"(rms {sky_std:.5f}, median ERR {np.median(noise[sky_pix]):.5f})")

    mask_refit = (~others & ~bad).astype("u1")
    c0 = FRAME // 2 - CUTOUT // 2
    mask_like = (mask_refit & (r < a.aperture / pixscale))[c0:c0 + CUTOUT, c0:c0 + CUTOUT].astype("u1")

    hdr = cut_sci.wcs.to_header()
    hdr["TARGET"] = a.name
    hdr["FILTER"] = filt
    hdr["BUNIT"] = "DN/s"
    hdr["SOURCE"] = mosaic_name
    hdr["PIXSCALE"] = (pixscale, "arcsec/pixel")
    hdr["CUTOUT"] = (CUTOUT, "ALPACA data.cutout_size (px)")
    hdr["THETAE"] = (a.theta_e, "approx. Einstein radius [arcsec] (literature)")
    hdr["LENSDX"] = (off_x * pixscale, "lens centroid - frame centre, arcsec (x)")
    hdr["LENSDY"] = (off_y * pixscale, "lens centroid - frame centre, arcsec (y)")
    hdr["SKYSUB"] = (float(sky), "DN/s subtracted")
    fits.writeto(os.path.join(out, "image.fits"), img, hdr, overwrite=True)
    fits.writeto(os.path.join(out, "noise_map.fits"), noise, hdr, overwrite=True)
    fits.writeto(os.path.join(out, "mask_lens_only.fits"), mask_refit, overwrite=True)
    fits.writeto(os.path.join(out, "mask_likelihood.fits"), mask_like, overwrite=True)

    # ------------------------------------------------------------------ 5. model PSF (STPSF)
    psf, opds = stpsf_mosaic_frame(rows, coord, filt, wcs, pixscale, work, sz["psf_native"])
    ph = fits.Header()
    ph["MODEL"] = "STPSF"
    ph["FILTER"] = filt
    ph["OVERSAMP"] = OVERSAMPLE
    ph["NEXP"] = len(rows)
    ph["DETS"] = ",".join(sorted({r["detector"] for r in rows}))
    ph["OPD"] = ",".join(opds)[:68]
    fits.writeto(os.path.join(out, "psf_stpsf_supersampled.fits"), psf.astype("f4"), ph, overwrite=True)
    log(f"PSF {psf.shape} from {len(rows)} exposures on {ph['DETS']}")

    # ------------------------------------------------------------------ 6. Gaia PSF stars
    from astroquery.gaia import Gaia
    Gaia.ROW_LIMIT = -1
    gaia = Gaia.cone_search_async(coord, radius=3 * u.arcmin,
                                  columns=["source_id", "ra", "dec", "phot_g_mean_mag"]).get_results()
    os.makedirs(os.path.join(out, "stars"), exist_ok=True)
    dxs, dys, kept = [], [], 0
    pf_min = min_peak_frac(psf)
    c_min = min_concentration(psf, STAR_SIZE)
    rejected = {"edge/blank": 0, "extended": 0, "off-centre peak": 0, "saturated/extended/faint": 0, "companion": 0}
    h = STAR_SIZE // 2
    for s in gaia:
        try:
            sc = Cutout2D(sci, SkyCoord(s["ra"], s["dec"], unit="deg"), STAR_SIZE, wcs=wcs, mode="strict")
            se = Cutout2D(err, SkyCoord(s["ra"], s["dec"], unit="deg"), STAR_SIZE, wcs=wcs, mode="strict")
        except Exception:  # noqa: BLE001 - off the mosaic
            continue
        d, e = sc.data / photmjsr, se.data / photmjsr
        if not (np.all(np.isfinite(d)) and np.all(np.isfinite(e))):
            rejected["edge/blank"] += 1
            continue
        # recentre on the actual peak (proper motion since the Gaia epoch), then apply the cuts
        py, px = np.unravel_index(np.argmax(d), d.shape)
        if abs(px - h) > 4 or abs(py - h) > 4:
            rejected["off-centre peak"] += 1
            continue
        gx, gy = sc.to_original_position((px, py))
        sc = Cutout2D(sci, (gx, gy), STAR_SIZE, wcs=wcs, mode="strict")
        se = Cutout2D(err, (gx, gy), STAR_SIZE, wcs=wcs, mode="strict")
        ok, why = star_ok(sc.data / photmjsr, se.data / photmjsr, pf_min, c_min)
        if not ok:
            rejected[why] += 1
            continue
        fits.writeto(os.path.join(out, "stars", f"star_{kept}.fits"),
                     (sc.data / photmjsr).astype("f4"), sc.wcs.to_header(), overwrite=True)
        fits.writeto(os.path.join(out, "stars", f"rms_maps_{kept}.fits"),
                     (se.data / photmjsr).astype("f4"), se.wcs.to_header(), overwrite=True)
        dxs.append(gx - xc)
        dys.append(gy - yc)
        kept += 1
    np.save(os.path.join(out, "stars", "stars_positions.npy"), np.array(list(zip(dxs, dys))))
    log(f"kept {kept} Gaia PSF stars (rejected: {rejected})")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[1], formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--name", required=True, help="lens name (written into the headers)")
    ap.add_argument("--ra", type=float, required=True, help="approximate lens RA [deg]")
    ap.add_argument("--dec", type=float, required=True, help="approximate lens Dec [deg]")
    ap.add_argument("--filter", required=True, help="NIRCam filter, e.g. F444W")
    ap.add_argument("--theta-e", type=float, required=True, help="approximate Einstein radius [arcsec]")
    ap.add_argument("--keep-r", type=float, required=True,
                    help="sources touching r < keep_r [arcsec] are the lens + arcs (kept); everything else is masked")
    ap.add_argument("--aperture", type=float, required=True, help="radius of the likelihood aperture [arcsec]")
    ap.add_argument("--out", default="data", help="output folder (default data/)")
    ap.add_argument("--work", default=".", help="folder for raw/ (the mosaic) and hdrs/ (exposure headers)")
    main(ap.parse_args())
