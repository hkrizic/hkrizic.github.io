"""Holes for two small field galaxies near SPT0418-47 that a first fit left in its residuals:
(-0.97", +2.18") r 0.45" (11 sigma, elongated) and (+1.52", +1.58") r 0.25" (compact), offsets from the frame centre.
Applied to data/mask_likelihood.fits (cutout) and data/mask_lens_only.fits (full frame), in place.
Run it once from the folder that holds data/ (the bundle's masks already contain the holes).
"""
import numpy as np
from astropy.io import fits

HOLES = [(-0.97, 2.18, 0.45), (1.52, 1.58, 0.25)]
ps = float(fits.getheader("data/image.fits")["PIXSCALE"])
for f in ("data/mask_likelihood.fits", "data/mask_lens_only.fits"):
    m = fits.getdata(f).astype("u1")
    n = m.shape[0]
    yy, xx = (np.indices(m.shape) - n // 2) * ps
    before = int(m.sum())
    for x, y, r in HOLES:
        m[np.hypot(xx - x, yy - y) < r] = 0
    fits.writeto(f, m, overwrite=True)
    print(f, m.shape, before, "->", int(m.sum()))
