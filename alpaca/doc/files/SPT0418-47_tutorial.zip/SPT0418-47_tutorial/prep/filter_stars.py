"""Quality cuts for PSF-star stamps (notebook-1 layout), applied in place with renumbering.

    python filter_stars.py <data_dir>

Rejects stamps that are saturated / extended (peak fraction < 0.35x, or r<3 px / r<12 px flux
concentration < 0.88x, the STPSF model's) / faint,
or that contain a companion: a significant (>3 sigma per pixel) secondary peak that is either
>3% of the star peak inside 20 px with no point-symmetric PSF counterpart, or >1% of the star
peak beyond 20 px (the PSF itself is <1e-3 of its peak there).
"""
import os
import sys

import numpy as np
from astropy.io import fits
from astropy.stats import sigma_clipped_stats
from photutils.detection import find_peaks
from scipy import ndimage


def min_peak_frac(psf_supersampled, oversample=3):
    """Saturation/extendedness threshold: 0.35 x the model PSF's peak fraction in 21x21 native px.

    Real (unsaturated) stars sit at ~0.6x the model value (pixel phase, drizzle broadening);
    saturated cores and galaxies fall far below. ~0.075 in F150W, ~0.043 in F444W.
    """
    n = psf_supersampled.shape[0] // oversample
    pb = psf_supersampled[:n * oversample, :n * oversample].reshape(n, oversample, n, oversample).sum((1, 3))
    cy, cx = np.unravel_index(np.argmax(pb), pb.shape)
    return 0.35 * pb.max() / pb[cy - 10:cy + 11, cx - 10:cx + 11].sum()


def concentration(d):
    """Flux in r < 3 px over flux in r < 12 px around the peak (sky-subtracted stamp)."""
    py, px = np.unravel_index(np.argmax(d), d.shape)
    yy, xx = np.indices(d.shape)
    r = np.hypot(xx - px, yy - py)
    return d[r < 3].sum() / d[r < 12].sum()


def min_concentration(psf_supersampled, stamp_size, oversample=3):
    """Extendedness threshold: 0.88 x the model PSF's concentration on the stamp grid.

    Isolated stars measure 0.92-0.99 of the model value; compact galaxies / blends fall below.
    """
    n = psf_supersampled.shape[0] // oversample
    pb = psf_supersampled[:n * oversample, :n * oversample].reshape(n, oversample, n, oversample).sum((1, 3))
    cy, cx = np.unravel_index(np.argmax(pb), pb.shape)
    h = stamp_size // 2
    return 0.88 * concentration(pb[cy - h:cy + h + 1, cx - h:cx + h + 1])


def star_ok(d, e, peak_frac_min=0.08, conc_min=0.0):
    """(ok, reason) for one star stamp `d` with 1-sigma map `e`."""
    n = d.shape[0]
    h = n // 2
    if not (np.all(np.isfinite(d)) and np.all(np.isfinite(e)) and np.all(e > 0)):
        return False, "edge/blank"
    # local sky from the stamp border (the mosaics keep a sky pedestal; STARRED fits it per
    # star, but the cuts below must not see it as flux or as "companion" peaks)
    border = np.r_[d[:5].ravel(), d[-5:].ravel(), d[5:-5, :5].ravel(), d[5:-5, -5:].ravel()]
    _, sky, _ = sigma_clipped_stats(border, sigma=3)
    d = d - sky
    py, px = np.unravel_index(np.argmax(d), d.shape)
    if abs(px - h) > 4 or abs(py - h) > 4:
        return False, "off-centre peak"
    peak_frac = d.max() / d[h - 10:h + 11, h - 10:h + 11].sum()
    if peak_frac < peak_frac_min or d.max() / e[py, px] < 50:
        return False, "saturated/extended/faint"
    if concentration(d) < conc_min:
        return False, "extended"
    sm = ndimage.gaussian_filter(d, 1)
    pk = find_peaks(sm, 0.01 * sm.max(), box_size=5)
    for qx, qy in zip(pk["x_peak"], pk["y_peak"]) if pk is not None else []:
        ddx, ddy = qx - px, qy - py
        r = np.hypot(ddx, ddy)
        if r <= 3:
            continue
        if sm[qy, qx] < 3 * e[qy, qx]:
            continue  # not significant (noise peak)
        if r >= 20:
            return False, "companion"
        mx, my = px - ddx, py - ddy
        mirrored = sm[my, mx] if (0 <= mx < n and 0 <= my < n) else 0.0
        if sm[qy, qx] > 0.03 * sm.max() and sm[qy, qx] > 3 * max(mirrored, 0) + 3 * e[qy, qx]:
            return False, "companion"
    return True, "ok"


def main(data_dir):
    sd = os.path.join(data_dir, "stars")
    pos = np.load(os.path.join(sd, "stars_positions.npy"))
    psf = fits.getdata(os.path.join(data_dir, "psf_stpsf_supersampled.fits")).astype(float)
    pf_min = min_peak_frac(psf)
    c_min = min_concentration(psf, fits.getdata(os.path.join(sd, "star_0.fits")).shape[0]) if len(pos) else 0.0
    keep = []
    for i in range(len(pos)):
        ok, why = star_ok(fits.getdata(os.path.join(sd, f"star_{i}.fits")).astype(float),
                          fits.getdata(os.path.join(sd, f"rms_maps_{i}.fits")).astype(float), pf_min, c_min)
        print(f"star_{i}: {why}")
        if ok:
            keep.append(i)
    for j, i in enumerate(keep):
        if i != j:
            for p in ("star", "rms_maps"):
                os.replace(os.path.join(sd, f"{p}_{i}.fits"), os.path.join(sd, f"{p}_{j}.fits"))
    for k in range(len(keep), len(pos)):
        for p in ("star", "rms_maps"):
            f = os.path.join(sd, f"{p}_{k}.fits")
            if os.path.exists(f):
                os.remove(f)
    np.save(os.path.join(sd, "stars_positions.npy"), pos[keep])
    print(f"kept {len(keep)}/{len(pos)}")


if __name__ == "__main__":
    main(sys.argv[1])
