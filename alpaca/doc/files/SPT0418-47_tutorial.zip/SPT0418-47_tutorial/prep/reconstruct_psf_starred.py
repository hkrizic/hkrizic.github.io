"""
Empirical JWST PSF with STARRED — script port of alpaca/preprocessing/2_Reconstruct_PSF_J1721.ipynb
(same parameters and fitting sequence), run on the Gaia star stamps written by prepare_gg.py
(stars/star_i.fits, stars/rms_maps_i.fits, stars/stars_positions.npy with the star offsets from the lens in
pixels). Runs in minutes on a GPU, ~10 min on a CPU for 6 stars.

    python reconstruct_psf_starred.py <data_dir>

Writes to <data_dir>/psf_starred/ (STARRED export + plots) and, for ALPACA's joint-PSF mode, to
<data_dir>/:
  psf_supersampled.fits           full PSF at the lens position (field distortion (0, 0)), 3x: the kernel ALPACA reads
  psf_starred_seed.npz            STARRED kwargs, flat "group.key" (psf.joint.seed_path)
  psf_error_map.fits              STARRED 'std_residuals' error map, 3x grid (psf.input.error_map_path)
"""
import glob
import os
import re
import sys

import matplotlib

matplotlib.use("Agg")
import jax  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from astropy.io import fits  # noqa: E402
from starred.plots import plot_function as pltf  # noqa: E402
from starred.procedures.psf_routines import run_multi_steps_PSF_reconstruction  # noqa: E402
from starred.psf.parameters import ParametersPSF  # noqa: E402
from starred.psf.psf import PSF  # noqa: E402

jax.config.update("jax_enable_x64", True)

# ---- notebook parameters (unchanged) ----
subsampling_factor = 3
lambda_scales = 2.
lambda_hf = 2.
lambda_positivity = 0.
adjust_sky = True
field_distortion = True
noise_method = "SLIT"
include_moffat = True
elliptical = True
convolution_method = "scipy"

data_dir = os.path.abspath(sys.argv[1])
data_path = os.path.join(data_dir, "stars")
outpath = os.path.join(data_dir, "psf_starred")
os.makedirs(outpath, exist_ok=True)
print("JAX backend:", jax.default_backend(), flush=True)

# ---- data (notebook cell 6) ----
key = lambda pat: (lambda x: int(re.search(pat, os.path.basename(x)).group(1)))  # noqa: E731
files = sorted(glob.glob(os.path.join(data_path, "star_*.fits")), key=key(r"star_(\d+)\.fits"))
files_rms = sorted(glob.glob(os.path.join(data_path, "rms_maps_*.fits")), key=key(r"rms_maps_(\d+)\.fits"))
data = np.array([fits.getdata(f).astype(float) for f in files])
sigma_2 = np.array([fits.getdata(f).astype(float) ** 2 for f in files_rms])
N, image_size = data.shape[0], data.shape[1]
print(f"{N} stars, stamp {image_size}x{image_size}", flush=True)
if N < 2:
    raise SystemExit("need at least 2 stars")

stamp_coordinates = np.load(os.path.join(data_path, "stars_positions.npy"))
rescaling_factor = np.mean(np.abs(stamp_coordinates))
stamp_coordinates_scaled = stamp_coordinates / rescaling_factor
print("rescaling factor:", rescaling_factor)

# notebook cell 9: noise-map hygiene + renormalisation
masks = np.ones_like(data)
for i in range(N):
    zz = sigma_2[i] <= 0
    sigma_2[i][zz] = np.mean(sigma_2[i][~zz])
    sigma_2[i][~np.isfinite(sigma_2[i])] = 1e6
norm = data[0].max() / 100.
data /= norm
sigma_2 /= norm ** 2

# ---- model (notebook cell 11) ----
model = PSF(image_size=image_size, number_of_sources=N, upsampling_factor=subsampling_factor,
            convolution_method=convolution_method, include_moffat=include_moffat,
            elliptical_moffat=elliptical, field_distortion=field_distortion)
kwargs_init, kwargs_fixed, kwargs_up, kwargs_down = model.smart_guess(
    data, masks=masks, fixed_background=False, guess_method="max", adjust_sky=adjust_sky)
kwargs_init["kwargs_gaussian"]["x0"] = np.zeros(N)
kwargs_init["kwargs_gaussian"]["y0"] = np.zeros(N)
parameters = ParametersPSF(kwargs_init, kwargs_fixed, kwargs_up=kwargs_up, kwargs_down=kwargs_down)

# ---- fit (notebook cell 13) ----
kwargs_lbfgs = {"maxiter": 1000, "restart_from_init": True}
kwargs_optax1 = {"max_iterations": 5000, "min_iterations": None, "init_learning_rate": 1e-2,
                 "schedule_learning_rate": True, "restart_from_init": False,
                 "stop_at_loss_increase": False, "progress_bar": False, "return_param_history": True}
kwargs_optax2 = dict(kwargs_optax1, max_iterations=2500, init_learning_rate=1e-3)
fitting_sequence = [["background", "distortion"], ["moffat", "distortion"], ["moffat"]]
model, parameters, loss, kwargs_partial_list, LogL_list, loss_history_list = run_multi_steps_PSF_reconstruction(
    data, model, parameters, sigma_2, masks=masks, star_positions=stamp_coordinates_scaled,
    lambda_scales=lambda_scales, lambda_hf=lambda_hf, lambda_positivity=lambda_positivity,
    fitting_sequence=fitting_sequence, optim_list=["l-bfgs-b", "adabelief", "adabelief"],
    kwargs_optim_list=[kwargs_lbfgs, kwargs_optax1, kwargs_optax2],
    method_noise=noise_method, regularize_full_psf=False, verbose=True, adjust_sky=adjust_sky)
kwargs_final = kwargs_partial_list[-1]

# ---- diagnostics (notebook cells 14-16) ----
for i, kw in enumerate(kwargs_partial_list):
    pltf.multiple_PSF_plot(model, data, sigma_2, kw, masks=masks, units="e-").savefig(
        os.path.join(outpath, f"fit_step_{i}_multiple.png"))
    plt.close("all")
for i, lh in enumerate(loss_history_list):
    pltf.plot_loss(lh).savefig(os.path.join(outpath, f"loss_{i}.png"))
    plt.close("all")
chi2 = float(-2 * loss._log_likelihood_chi2(kwargs_final) / (image_size ** 2) / N)
resid = (data - np.asarray(model.model(**kwargs_final, positions=stamp_coordinates_scaled))) / np.sqrt(sigma_2)
info = f"stars {N}\nreduced chi2 {chi2:.4f}\nresid mean {resid.mean():.4f} std {resid.std():.4f}\n"
open(os.path.join(outpath, "info.txt"), "w").write(info)
print(info, flush=True)

# ---- export (notebook cell 18; includes STARRED's std_residuals PSF error map) ----
model.export(outpath, kwargs_final, data, sigma_2, format="fits",
             star_positions=stamp_coordinates_scaled, full_psf_position=np.array([0., 0.]))

# ---- ALPACA inputs ----
full = np.asarray(model.get_full_psf(**kwargs_final, norm=True, high_res=True, position=np.array([0., 0.])))
hdr = fits.Header()
hdr["MODEL"] = "STARRED"
hdr["OVERSAMP"] = subsampling_factor
hdr["NSTARS"] = N
hdr["REDCHI2"] = chi2
hdr["POSITION"] = "lens (field-distortion origin)"
fits.writeto(os.path.join(data_dir, "psf_supersampled.fits"), full.astype("f4"), hdr, overwrite=True)   # the kernel ALPACA reads (PSF_PATH)

err = fits.getdata(os.path.join(outpath, "psf_error_map.fits"))
eh = fits.Header()
eh["ERRMETH"] = "std_residuals"
eh["NSTARS"] = N
fits.writeto(os.path.join(data_dir, "psf_error_map.fits"), np.asarray(err, "f4"), eh, overwrite=True)

flat = {}
for group, kw in kwargs_final.items():
    for k, v in kw.items():
        flat[f"{group}.{k}"] = np.atleast_1d(np.asarray(v, dtype="f4"))
flat["upsampling_factor"] = np.array(subsampling_factor)
flat["elliptical_moffat"] = np.array(elliptical)
np.savez(os.path.join(data_dir, "psf_starred_seed.npz"), **flat)
print("wrote psf_supersampled.fits", full.shape, "psf_error_map.fits", np.shape(err),
      "psf_starred_seed.npz", sorted(flat), flush=True)
