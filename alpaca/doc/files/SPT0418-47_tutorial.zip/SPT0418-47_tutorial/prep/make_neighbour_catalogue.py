"""A perturber catalogue for the small galaxy 2.4" north-east of SPT0418-47 (the tutorial's worked perturber example).

The galaxy's light is already masked; this gives it a MASS. Its redshift is unknown, so it is put on the lens plane
(the usual assumption), with theta_E from its F444W flux relative to the lens (Faber-Jackson: theta_E ~ sqrt(L))
and a 40 % prior width. Positions are in the model frame: pixel_xy in data/image.fits (no RA/Dec needed).
usage: python -I prep/make_neighbour_catalogue.py   -> data/perturbers_neighbour.json
"""
import json

import numpy as np
from astropy.io import fits

img = fits.getdata("data/image.fits").astype(float)
h = fits.getheader("data/image.fits")
ps, N = float(h["PIXSCALE"]), img.shape[0]
light = np.load("run/03_multistart/stage2_lens_light_refit/refit_arrays.npz")["light"].astype(float)   # lens model
yy, xx = np.indices(img.shape)
c = (N - 1) / 2                                   # the frame centre, in pixels
x0, y0, r = -0.97, 2.18, 0.45                     # the galaxy, arcsec from the frame centre (seen in the residuals)
m = np.hypot((xx - c) * ps - x0, (yy - c) * ps - y0) < r
resid = img - light                               # the galaxy's own light
f = resid[m].sum()
px, py = (resid[m] * xx[m]).sum() / f, (resid[m] * yy[m]).sum() / f       # flux-weighted centroid [pixels]
theta_E_main = 1.22
theta_E = theta_E_main * np.sqrt(f / light.sum())
d = np.hypot((px - c) * ps, (py - c) * ps)
cat = {
    "target": {"z_lens": 0.263, "z_source": 4.225, "pix_scale_arcsec": ps, "npix": N,
               "theta_E_main_arcsec": theta_E_main, "ra_deg": None, "dec_deg": None},
    "perturbers": [{
        "id": 1, "ra_deg": None, "dec_deg": None,
        "pixel_xy": [round(float(px), 2), round(float(py), 2)],
        "redshift": {"z": 0.263, "source": "assumed", "reference": "unknown; lens-plane assumption"},
        "profile": {"mass_model": "SIS", "theta_E_arcsec": round(float(theta_E), 4)},
        "theta_E_prior_sigma": round(0.4 * float(theta_E), 4),
        "theta_E_max_factor": 3.0,
        "fix_positions": True,
        "flexion_shift_arcsec": float(theta_E_main ** 2 * theta_E ** 2 / d ** 3),
        "notes": f"small galaxy {d:.2f}\" NE; F444W flux {f / light.sum():.4f} x the lens; light masked",
    }],
}
json.dump(cat, open("data/perturbers_neighbour.json", "w"), indent=1)
print(json.dumps(cat["perturbers"][0], indent=1))
