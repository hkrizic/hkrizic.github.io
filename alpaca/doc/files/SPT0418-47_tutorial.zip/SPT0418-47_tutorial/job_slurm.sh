#!/bin/bash
# SPT0418-47 with ALPACA on a Slurm cluster. Adapt the partition / account / GPU request to your cluster.
# usage (from this folder):
#   sbatch --gres=gpu:1 job_slurm.sh --fit-only     # the best fit: one GPU with >= 24 GB, ~20 min
#   sbatch job_slurm.sh                             # best fit (resumed) + sampling: two GPUs of the same type
#SBATCH --job-name=SPT0418_alpaca
#SBATCH --gres=gpu:2
#SBATCH --cpus-per-task=8
#SBATCH --mem=64G
#SBATCH --time=12:00:00
#SBATCH --output=SPT0418_alpaca_%j.log
##SBATCH --partition=<your GPU partition>
##SBATCH --account=<your account>
set -uo pipefail
# activate the environment that has ALPACA, e.g.
# source /path/to/alpaca/.venv/bin/activate      or      conda activate alpaca
export JAX_ENABLE_X64=true XLA_PYTHON_CLIENT_PREALLOCATE=false MPLBACKEND=Agg PYTHONUNBUFFERED=1
# two GPUs: let JAX see CUDA and the CPU (not --backend gpu), so the two NUTS chains run in parallel
export JAX_PLATFORMS=cuda,cpu
cd "${SLURM_SUBMIT_DIR:-$(dirname "$0")}"
python -c "import jax; print('devices:', jax.devices())"
python -u run_alpaca.py config.json "$@"
