"""
Lens Modeling Pipeline Script (Generic)

Entry-point for running the Alpaca lens modeling pipeline. Ships configured
for the bundled worked example — HE0435-1223, a quadruply imaged quasar
(JWST/NIRCam F150W) with measured time delays, data in ``./data/`` and the
full production configuration in ``./config.json``. To model your own lens,
edit the data paths / positions / delays below and supply your own config.

Configuration is loaded in the following order of preference:

1. A JSON config file passed on the command line (preferred, reproducible):
   ``python run_alpaca.py config.json``
2. ``default_config.py`` in this directory (edit constants at the top).

Pipeline phases:
    1. MAP estimation — staged multi-start GD (gd -> lens_light_refit ->
       cf_warmstart -> cf_joint), joint PSF fitted inside the stages
    2. Posterior sampling — NUTS, Nautilus, or NIFTy (geoVI + NUTS-in-ξ)
    (iterative STARRED PSF reconstruction available as an optional
    preliminary via psf.mode="iterative"; off by default)

Author: hkrizic
"""

import os
import sys

import matplotlib.pyplot as plt
import numpy as np

# =============================================================================
# 1. DATA PATHS  (edit these to point to your FITS / npy files)
#
#    The PSF_* fields below are per-dataset OVERRIDES of the loaded config:
#    every one of them set to None means "keep whatever the config file (or
#    default_config.py) says"; a non-None value replaces the config value
#    after loading. Keep the science settings in the config and only the
#    dataset-specific paths here.
# =============================================================================
IMAGE_PATH = "./data/image.fits"       # 2-D lens image (249 px frame, F444W)
PSF_PATH = "./data/psf_supersampled.fits"   # 3x supersampled STARRED kernel (= the joint-PSF seed)
NOISE_MAP_PATH = "./data/noise_map.fits"

# Supersampling factor of the PSF file relative to the data pixel grid.
# None = use the config value (psf.input.oversample).
# 1 = PSF sampled at the data resolution (the usual case).
# >1 = PSF provided at N× finer sampling (e.g. a PSF at 3× or 5× oversampling).
PSF_OVERSAMPLE = None

# STARRED-kwargs seed for the JOINT PSF mode (.npz with kwargs_moffat +
# kwargs_background, as written by a STARRED/JWSTPSF fit). Only used when
# psf.mode == "joint". None = use the config value (psf.joint.seed_path).
PSF_STARRED_KWARGS_PATH = None

# Measured per-pixel uncertainty map of the input PSF (FITS, same grid as the
# PSF background). Feeds the joint background prior when
# psf.joint.priors.background.type == "error_map".
# None = use the config value (psf.input.error_map_path).
PSF_ERROR_MAP_PATH = None

# Optional boolean mask excluding pixels from the likelihood (e.g. bright
# companions). Path to a .npy or .fits boolean array matching the image shape.
# None = use the config value (data.likelihood_mask_path).
LIKELIHOOD_MASK_PATH = None

# Line-of-sight perturber catalog (JSON from the perturber-finder tool:
# target block + perturbers with RA/Dec, redshifts, SIS theta_E). When set,
# one SIS profile per perturber is added to the lens model; same-plane
# perturbers join the main plane, off-plane ones trigger multi-plane lensing.
# Perturber light is NOT modelled — mask it via LIKELIHOOD_MASK_PATH.
# None = use the config value (model.perturbers.path; null there = disabled).
PERTURBERS_PATH = None

# =============================================================================
# 2. APPROXIMATE POINT SOURCE IMAGE POSITIONS  (arcsec, relative to lens center)
#
#    These approximate positions are used to LABEL the auto-detected images
#    (A, B, C, D), so that time delays are assigned to the correct pairs.
#    The pipeline always auto-detects the actual positions from the image.
#    The reference image for time delays is set explicitly via REFERENCE_IMAGE
#    below -- dict iteration order is NOT used.
#    Set IMAGE_POSITIONS = None to use the automatic clockwise-from-north
#    geometric labeling fallback instead.
# =============================================================================
IMAGE_POSITIONS = None   # SPT0418-47: galaxy-galaxy lens, no point sources

# Label of the reference image (the anchor of the delays in the likelihood).
# Overridden by likelihood.time_delays.reference_image when that is set.
REFERENCE_IMAGE = None

# =============================================================================
# 2b. APPROXIMATE LENS GALAXY CENTER  (arcsec, relative to image center)
#
#     Used to set the lens center prior and to define the lens/arc regions
#     for amplitude priors.  The pipeline uses this as the mean of a Normal
#     prior on the lens center position.
# =============================================================================
LENS_POSITION = (0.0126, -0.0276)   # lens light centroid - frame centre (image.fits LENSDX/LENSDY)
# =============================================================================
# 3. TIME DELAYS  (DAYS)
#
#    The delays belong in the config, ``likelihood.time_delays`` (see config.json):
#    paste the published n-1 delays relative to one reference image (A), e.g.
#
#      "time_delays": {
#        "convention": "t_X - t_Y",            # published (COSMOGRAIL/TDCOSMO): Δt_XY = t_X - t_Y
#        "delays": {"AB": [-9.0, 0.8], "AC": [-0.8, 0.7], "AD": [-13.8, 0.8]},
#        "covariance": "independent"
#      }
#
#    [value, error] or [value, +error, -error] (symmetrised); "independent": each
#    delay enters the likelihood with its own error.
#    The run log prints the delays and errors the likelihood uses.
#    Switch the delays off with likelihood.use_time_delays = false.
#
#    TIME_DELAYS below overrides the config (None = use the config). It accepts the
#    same block, or the ALPACA <= 0.5.1 form {label: (t_X - t_ref, error)} for the
#    non-reference images (independent errors; NOTE: t_X - t_ref is the opposite
#    sign of the published Δt).
# =============================================================================
TIME_DELAYS = None

# =============================================================================
# MAIN
# =============================================================================

def main():
    """
    Run the complete ALPACA lens modeling pipeline on generic data.

    Loads data from paths defined at the top of this script, builds
    a ``PipelineConfig`` via ``run_config.load_config``, executes the
    three pipeline phases (PSF reconstruction, gradient descent, posterior
    sampling), and prints a summary of the results including parameter
    estimates, marginalized posterior plots, and BIC.

    Usage
    -----
    .. code-block:: bash

        python run_alpaca.py                # use default_config.py settings
        python run_alpaca.py config.json    # load config from JSON

    Returns
    -------
    None
        All outputs are saved to disk and printed to stdout.
    """
    import argparse

    parser = argparse.ArgumentParser(description="ALPACA lens modelling pipeline")
    parser.add_argument("config", nargs="?", help="Pipeline JSON configuration")
    parser.add_argument("--backend", choices=("auto", "cpu", "gpu", "cuda", "mps"))
    parser.add_argument("--precision", choices=("auto", "float32", "float64"))
    parser.add_argument("--fit-only", action="store_true", help="Run all configured fitting stages and stop before posterior sampling")
    parser.add_argument("--output", help="Override the result directory")
    args = parser.parse_args()
    if args.backend is not None:
        os.environ["ALPACA_BACKEND"] = args.backend
    if args.precision is not None:
        os.environ["ALPACA_PRECISION"] = args.precision

    from alpaca.pipeline import run_pipeline
    from alpaca.utils import load_config_from_json, load_data, parse_positions_and_delays
    from alpaca.utils.bic import compute_bic_from_results
    from alpaca.utils.blinding import blinded_view

    try:
        from default_config import build_config
    except ImportError:
        build_config = None

    print("=" * 50)
    print("=" * 50)
    print("ALPACA Lens Modeling Pipeline")
    print("=" * 50)
    print("=" * 50)
    print("\nThis script runs the complete lens modeling pipeline:")
    print("  Phase 1: MAP estimation (staged gradient descent)")
    print("  Phase 2: Posterior sampling (NIFTy, NUTS, or Nautilus)")
    print("  (optional preliminary: iterative PSF reconstruction)")

    # ---- Configuration ----
    if args.config:
        json_path = args.config
        print(f"\nLoading pipeline config from: {json_path}")
        config = load_config_from_json(json_path)
    elif build_config is not None:
        print("\nUsing default_config.py for pipeline settings.")
        config = build_config()
        if TIME_DELAYS is None and config.likelihood.time_delays is None:
            config.likelihood.use_time_delays = False
    else:
        print("ERROR: No JSON config provided and default_config.py not found.")
        print("Usage: python run_alpaca.py <config.json>")
        sys.exit(1)

    if args.fit_only:
        config.run_sampling = False
    if args.output:
        config.output_dir = args.output
    source = getattr(config, "_config_source", None)
    if source is not None:
        source.setdefault("run", {}).update(
            output_dir=config.output_dir, sampling=config.run_sampling)

    # Apply data-level overrides from this script (override the loaded config).
    # Each PSF_* constant above that is None leaves the config value untouched.
    if PSF_OVERSAMPLE is not None:
        config.psf.input.oversample = int(PSF_OVERSAMPLE)
        print(f"  Input PSF has oversampling factor = {config.psf.input.oversample}")
    if PSF_STARRED_KWARGS_PATH is not None:
        config.psf.joint.seed_path = str(PSF_STARRED_KWARGS_PATH)
        print(f"  Joint-PSF STARRED seed: {config.psf.joint.seed_path}")
    if PSF_ERROR_MAP_PATH is not None:
        config.psf.input.error_map_path = str(PSF_ERROR_MAP_PATH)
        print(f"  PSF error map: {config.psf.input.error_map_path}")
    if LIKELIHOOD_MASK_PATH is not None:
        config.data.likelihood_mask_path = str(LIKELIHOOD_MASK_PATH)
        print(f"  Likelihood mask: {config.data.likelihood_mask_path}")
    if PERTURBERS_PATH is not None:
        config.model.perturbers.path = str(PERTURBERS_PATH)
        print(f"  Perturber catalog: {config.model.perturbers.path}")

    print("\nStarting pipeline...\n")

    # ---- Load data ----
    print("\nLoading data...")
    print(f"  Image:     {IMAGE_PATH}")
    print(f"  PSF:       {PSF_PATH}")
    print(f"  Noise map: {NOISE_MAP_PATH}")

    img, psf_kernel, noise_map = load_data(IMAGE_PATH, PSF_PATH, NOISE_MAP_PATH)

    print(f"  Image shape: {img.shape}")
    print(f"  PSF shape:   {psf_kernel.shape}")

    # ---- Parse positions and time delays ----
    # TIME_DELAYS (this script) overrides the config's likelihood.time_delays
    time_delays = TIME_DELAYS if TIME_DELAYS is not None else config.likelihood.time_delays
    use_point_sources = bool(getattr(config.model, "use_point_sources", True))
    if use_point_sources and config.likelihood.use_time_delays and time_delays is None:
        print("ERROR: likelihood.use_time_delays is true but no delays were given.\n"
              "  Since ALPACA 0.5.2 the delays live in the config: add a likelihood.time_delays block, e.g.\n"
              '    "time_delays": {"convention": "t_X - t_Y", "delays": {"AB": [-9.0, 0.8], ...},\n'
              '                    "covariance": "independent"}\n'
              "  (see README.md / alpaca.utils.time_delays), or set TIME_DELAYS at the top of this script,\n"
              "  or set likelihood.use_time_delays = false.")
        sys.exit(2)
    if not use_point_sources:
        # Galaxy-galaxy mode: no point-source detection/labelling and no
        # time delays, so the quasar-only inputs above are not used.
        print("\nGalaxy-galaxy mode (point sources off): extended-source-only fit.")
        if IMAGE_POSITIONS is not None or time_delays is not None:
            print("  IMAGE_POSITIONS / TIME_DELAYS are set but ignored in this mode.")
        image_positions = measured_delays = delay_errors = labels = None
    else:
        print("\nPoint source images:")
        if time_delays is not None:
            print("Time delays:")
        image_positions, measured_delays, delay_errors, labels = (
            parse_positions_and_delays(
                IMAGE_POSITIONS,
                time_delays,
                reference_image=REFERENCE_IMAGE if time_delays is not None else None,
            )
        )

    if not use_point_sources:
        pass
    elif image_positions is None:
        print("  No approximate image positions provided.")
        print(
            "  Detected images will be auto-labeled with the clockwise-from-north "
            "geometric fallback (NOT the H0LiCOW/TDCOSMO published convention)."
        )
        if labels is not None:
            print(f"  Expected label order: {', '.join(labels)}")
    else:
        n_images = len(labels)
        print(f"  {n_images} images: {', '.join(labels)}")
        for label, (x, y) in IMAGE_POSITIONS.items():
            print(f"    {label}: ({x:+.4f}, {y:+.4f}) arcsec")

    if measured_delays is None and use_point_sources:
        print("\nNo time delays provided (running without time-delay likelihood).")

    # ---- Run pipeline ----
    results = run_pipeline(
        config=config,
        img=img,
        psf_kernel=psf_kernel,
        noise_map=noise_map,
        image_positions=image_positions,
        lens_center=LENS_POSITION,
        measured_delays=measured_delays,
        delay_errors=delay_errors,
        time_delay_labels=labels,
        verbose=True,
    )

    # ---- Explore results ----
    output_dir = results["output_dirs"]["root"]
    print(f"\nResults saved to: {output_dir}")
    print("\nDirectory structure:")
    for name, path in results["output_dirs"].items():
        rel_path = os.path.relpath(path, output_dir)
        print(f"  {name}: {rel_path}")

    # PSF Reconstruction Results
    if "psf_result" in results and results["psf_result"] is not None:
        psf_result = results["psf_result"]
        print("\nPSF Reconstruction:")
        print(f"  Number of iterations: {psf_result['n_iterations']}")
    else:
        print("\nPSF reconstruction was not run.")

    # Multi-start Optimization Results
    if "multistart_summary" in results and results["multistart_summary"] is not None:
        ms_summary = results["multistart_summary"]
        print("\nMulti-start Optimization:")
        print(f"  Number of starts: {ms_summary.get('n_starts', 'N/A')}")
        print(f"  Best run: {ms_summary.get('best_run', 'N/A')}")
        _bl = ms_summary.get('best_loss')
        print(f"  Best loss: {_bl:.4f}" if _bl is not None else "  Best loss: N/A")

        chi2_reds = ms_summary.get('chi2_reds', [])
        if len(chi2_reds) > 0:
            best_chi2 = chi2_reds[ms_summary.get('best_run', 0)]
            print(f"  Best chi2_red: {best_chi2:.4f}")

    # Posterior Sampling Results
    if "posterior" in results and results["posterior"] is not None:
        posterior = results["posterior"]
        # Display-only stats/histograms use blinded values when blinding is on.
        _disp = blinded_view(posterior)
        samples = _disp["samples"]
        param_names = _disp.get("param_names", [])

        print("\nPosterior Sampling:")
        print(f"  Engine: {posterior.get('engine', 'N/A')}")
        print(f"  Number of samples: {samples.shape[0]}")

        print("\n  Parameter summaries (mean +/- std):")
        key_params = [
            "lens_theta_E", "lens_gamma", "lens_e1", "lens_e2",
            "light_Re_L", "light_n_L", "D_dt",
        ]
        for param in key_params:
            if param in param_names:
                idx = param_names.index(param)
                vals = samples[:, idx]
                print(f"    {param}: {np.mean(vals):.4f} +/- {np.std(vals):.4f}")

        if "log_sigma_rayshoot_sys" in param_names:
            idx = param_names.index("log_sigma_rayshoot_sys")
            log_vals = samples[:, idx]
            vals = np.exp(log_vals)
            print(f"    sigma_rayshoot_sys: {np.mean(vals)*1000:.4f} +/- {np.std(vals)*1000:.4f} mas")
        elif "sigma_rayshoot_sys" in param_names:
            idx = param_names.index("sigma_rayshoot_sys")
            vals = samples[:, idx]
            print(f"    sigma_rayshoot_sys: {np.mean(vals)*1000:.4f} +/- {np.std(vals)*1000:.4f} mas")

        # Marginalized Posteriors
        key_params_plot = [
            p for p in ["lens_theta_E", "lens_gamma", "light_Re_L", "light_n_L", "D_dt"]
            if p in param_names
        ]

        if key_params_plot:
            fig, axes = plt.subplots(1, len(key_params_plot), figsize=(4*len(key_params_plot), 4))
            if len(key_params_plot) == 1:
                axes = [axes]

            for ax, param in zip(axes, key_params_plot):
                idx = param_names.index(param)
                vals = samples[:, idx]
                ax.hist(vals, bins=50, density=True, alpha=0.7, color="steelblue")
                ax.axvline(np.median(vals), color="red", linestyle="--")
                ax.set_xlabel(param)

            plt.tight_layout()
            plot_save_path = os.path.join(output_dir, "marginalized_posteriors.png")
            plt.savefig(plot_save_path)
            print(f"\nCustom analysis plot saved to: {plot_save_path}")
            if plt.isinteractive():
                plt.show()
            plt.close("all")

        # BIC
        try:
            bic_info = compute_bic_from_results(results)
            print("\n" + "=" * 50)
            print("BIC (Bayesian Information Criterion)")
            print("=" * 50)
            print(f"  BIC = {bic_info['bic']:.2f}")
            print(f"  n_params = {bic_info['n_params']}")
            print(f"  n_pixels = {bic_info['n_pixels']}")
            print(f"  log(L_max) = {bic_info['log_L_max']:.2f}")
            print(f"  shapelets_n_max = {bic_info['shapelets_n_max']}")
            print("\nNote: Lower BIC is better for model comparison.")
        except Exception as e:
            print(f"\nCould not compute BIC: {e}")


if __name__ == "__main__":
    main()
