# SPT0418-47 — ALPACA galaxy–galaxy tutorial folder

Everything the ALPACA galaxy–galaxy tutorial (`doc/tutorial-galaxy.html` on the ALPACA website) uses to fit the
Einstein ring SPT0418-47 in JWST/NIRCam F444W data (programme 1355, TEMPLATES).

## Run it

```bash
# ALPACA installed (see the tutorial, step 2); from this folder:
python run_alpaca.py config.json --fit-only     # the best fit (~20 min on one GPU)
python run_alpaca.py config.json                # best fit (resumed) + posterior sampling (two GPUs, a few hours)
sbatch job_slurm.sh                             # the same on a Slurm cluster (edit the partition/account first)
```

Results are written to `run/`. Start with `run/03_multistart/best_model/model_summary.png`.

## Contents

| path | what |
|---|---|
| `data/image.fits` | full frame (249 × 249 px, 0.063″/px, 15.7″), lens centred, DN/s, sky subtracted |
| `data/noise_map.fits` | 1σ per pixel (the mosaic's ERR extension) |
| `data/mask_likelihood.fits` | model cutout (109 × 109): 1 = pixel used in the fit |
| `data/mask_lens_only.fits` | full frame: lens + sky only, for the lens-light refit |
| `data/psf_supersampled.fits` | STARRED PSF, 3× supersampled (the kernel ALPACA reads) |
| `data/psf_starred_seed.npz` | STARRED parameters: ALPACA's joint PSF is built from them |
| `data/psf_error_map.fits` | per-pixel PSF uncertainty (the prior width of the live PSF) |
| `data/psf_stpsf_supersampled.fits` | STPSF model PSF (for the star cuts; a comparison only) |
| `data/stars/` | the six Gaia PSF stars and their noise maps |
| `data/perturbers_neighbour.json` | the worked perturber example (tutorial step 10): the small galaxy 2.4″ NE as an SIS |
| `config.json` | the full ALPACA configuration of the tutorial's final model |
| `run_alpaca.py` | ALPACA's run script with the file paths and the lens position |
| `job_slurm.sh` | Slurm template |
| `prep/` | how `data/` was made (reproduces it bit for bit from the archive mosaic); `make_neighbour_catalogue.py` writes the perturber example |

## Remake the inputs (tutorial steps 4–9)

```bash
pip install astroquery photutils stpsf starred-astro      # plus the STPSF data files (STPSF_PATH)
cd prep
python prepare_gg.py --name SPT0418-47 --ra 64.66533 --dec -47.86465 --filter F444W \
                     --theta-e 1.3 --keep-r 2.6 --aperture 3.2 --out ../data --work ..
python reconstruct_psf_starred.py ../data                  # the STARRED PSF (GPU recommended)
cd .. && python prep/mask_neighbours.py                    # two holes for small neighbouring galaxies
```

`prepare_gg.py` downloads the F444W mosaic (136 MB) from MAST, cuts the frame, converts the units, builds both masks,
subtracts the sky, makes an STPSF model PSF and cuts Gaia star stamps. STARRED's optimisation is not bit-for-bit
reproducible across machines; expect a PSF that agrees to well below its error map.

Data: JWST ERS programme 1355 (PI J. R. Rigby), retrieved from MAST.
